package graph;

import java.util.*;

public class DepthFirstTraversal<T> extends AdjacencyGraph<T> implements Traversal<T> {

    private Queue<T> toDo = new ArrayDeque<T>(); // to do queue
    private List<T> traversal = new ArrayList<T>(); // traversal list
    private Queue<T> backTrack = new ArrayDeque<T>(); // back track queue


   @Override
    public List<T> traverse() throws GraphError {
       T currentNode = getUnvisitedNode(); // get an unvisited node
       while (currentNode != null) {
           Set<T> nodeNeighbours = getNeighbours(currentNode);
           if (!nodeNeighbours.isEmpty()){
               backTrack.add(currentNode);
               for (T t : nodeNeighbours){
                    if (!visited(t)){

                    }
               }

           }


       }
       return null;
    }

    private T getUnvisitedNode() {
        for (T node: getNodes()) { // check all the nodes
            if (!visited(node)) { // if this node has not been "visited"
                return node; // then this is an unvisited node
            }
        }
        return null; // so return null
    }

    private boolean visited(T node) {
        return
                traversal.contains(node) // the node has been visited and is in the traversal
                        || toDo.contains(node); // or it is in the to do list, and will therefore be visited
    }

}
